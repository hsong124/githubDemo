import json

def lambda_handler(event, context):
    # TODO implement
    print("hello world")
